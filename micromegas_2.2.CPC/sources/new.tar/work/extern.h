 extern double initQCD(double,double,double,double);
 extern double MbEff(double);
 extern double MtEff(double);
 extern double McEff(double);
